package com.game.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PlayerScoreTest {

    @Test
    public double guessTotalPoints(){
        while(true){
            double guess = Math.random();
            PlayerScore playerScore = new PlayerScore(4,30,0);
            if(Math.abs(guess)== playerScore.totalPoints()){
                return guess;
            }
        }

    }
    public double guessTotalCards(){
        while(true){
            double guess1 = Math.random();
            PlayerScore playerCards = new PlayerScore(3,8,1);
            if(Math.abs(guess1)== playerCards.totalCards()){
                return guess1;
            }
        }
    }

}