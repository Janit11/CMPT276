package com.GameText.ui;

import java.util.Scanner;
import com.game.model.Game;
import com.game.model.GameManager;

public class GameTextUI {
    private GameManager manager;
    public GameTextUI(GameManager manager) {
        this.manager = manager;
    }
    public void show(){

        boolean isDone = false;
        while (!isDone){
            System.out.println("Welcome to the game " );
            System.out.println("Menu:");
            System.out.println("----------------- ");
            System.out.println("1. List games");
            System.out.println("2. Start New game");
            System.out.println("3. Delete game");
            System.out.println("0. Exit");
            System.out.println("----------------- ");
            Scanner in = new Scanner(System.in);
            int scan = in.nextInt();
            switch(scan){
                case 0:
                    isDone = true;
                    break;
                case 1:
                    System.out.println("Games:");
                    System.out.println("-------------");
                    int gameInd =0;
                    for(Game game: manager){
                        gameInd++;
                        System.out.println(gameInd +"."+ game);
                    }
                    if(gameInd==0){
                        System.out.println("No games");
                    }

                    break;
                case 2:
                    System.out.print("How many players? ");
                    int numOfPlayers = in.nextInt();
                    if(numOfPlayers<=4){
                        Game g = new Game(numOfPlayers);
                        manager.add(g);
                    }
                    if(numOfPlayers<0 || numOfPlayers>4) {
                        throw new IllegalArgumentException("Game can only be played between 1 to 4 players");
                    }
                    break;

                case 3:
                    System.out.println("Games: ");
                    int index =0;
                    for(Game game: manager){
                        index++;
                        System.out.println(index +"."+ game);
                    }
                    if (index>0){
                        System.out.println(" ");
                        System.out.println("Which game to delete (0 for none)?");
                        int index1 = in.nextInt();
                        if(index1>0){
                            manager.remove(index1-1);

                        }
                        System.out.println("Game Deleted");
                    }
                    if(index==0){
                        System.out.println("No games");
                    }
                    break;

                default:
                    System.out.println("Error! Please enter 0,1,2 or 3.");
            }

        }
    }
}

