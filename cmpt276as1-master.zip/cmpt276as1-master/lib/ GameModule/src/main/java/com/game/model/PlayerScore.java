package com.game.model;

public class PlayerScore {
    private int pointCards;
    private int wagerCards;
    private int points;
    private int actualPoints;


    public PlayerScore(int pointCards, int wagerCards, int points) {

        this.pointCards = pointCards;
        this.wagerCards = wagerCards;
        this.points = points;

    }

    public int totalCards() {
        return pointCards + wagerCards;
    }

    public int totalPoints() {
        if (pointCards == 0) {
            actualPoints = 0;
        }
        if (pointCards != 0) {
            actualPoints = (points - 20);
            actualPoints = (wagerCards + 1) * actualPoints;

            if (totalCards() >= 8) {
                actualPoints = actualPoints + 20;

            }
        }

        return actualPoints;
    }

    @Override
    public String toString() {
        return "Player{" +
                ", pointCards=" + pointCards +
                ", wagerCards=" + wagerCards + ", points=" + points +
                '}';
    }

}