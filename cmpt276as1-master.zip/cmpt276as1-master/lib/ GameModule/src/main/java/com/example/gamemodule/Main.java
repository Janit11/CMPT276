package com.example.gamemodule;

import com.GameText.ui.GameTextUI;
import com.game.model.GameManager;

public class Main {

    public static void main(String[] args) {
        GameManager manager = new GameManager();
        GameTextUI ui = new GameTextUI(manager);
        ui.show();
    }
}