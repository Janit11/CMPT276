package com.example.gameapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


import com.google.android.material.floatingactionbutton.FloatingActionButton;

import ca.cmpt276.as2.model.Game;
import ca.cmpt276.as2.model.GameManager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupAddNewGameButton();
    }

    private void setUpNewGame(){
        Game game = new Game(2);
    }

    private void setupAddNewGameButton(){
        FloatingActionButton btn = (FloatingActionButton)findViewById(R.id.fab);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Let's Play.", Toast.LENGTH_SHORT )
                        .show();

                 Intent intent = SecondActivity.makeIntent(MainActivity.this);
                startActivity (intent);
            }

        });

    }
}