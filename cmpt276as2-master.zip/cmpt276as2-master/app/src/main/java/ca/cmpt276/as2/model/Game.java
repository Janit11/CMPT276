package ca.cmpt276.as2.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Game {
    int count = 0;
    private int players;
    private int ptCard;
    private int wgCard;
    private int sum;
    int winner;
    int[] intArray = new int[4];
    LocalDateTime timeDate = LocalDateTime.now();
    List<PlayerScore> playerScore = new ArrayList<>();
    PlayerScore playerScores;


    public Game(int players) {
        this.players = players;
        for (int i = 0; i < players; i++) {
            System.out.println("for player: " + (i + 1));
            System.out.print("How many cards?");
            Scanner cards = new Scanner(System.in);
            ptCard = cards.nextInt();
            if(ptCard< 0){
                throw new IllegalArgumentException("Cards cannot be negative.");
            }
            if (ptCard == 0) {
                wgCard = 0;
                sum = 0;
            }
            if (ptCard != 0) {
                System.out.print("Sum of cards ?");
                sum = cards.nextInt();
                System.out.print("How many wager cards?");
                wgCard = cards.nextInt();
            }
            if(sum<0){
                throw new IllegalArgumentException("Sum must be positive or 0.");
            }
            if(wgCard<0){
                throw new IllegalArgumentException("Number of Wager Cards cannot be negative.");
            }
            playerScores = new PlayerScore(ptCard, wgCard, sum);
            playerScore.add(playerScores);
        }
        System.out.println("----------------");
        System.out.println("Adding game");
        print();
    }

    public void print() {
        System.out.println(toString());
    }


    public int[] getWinner() {
        winner = playerScore.get(0).totalPoints();
        int k =0;
        intArray[k] = 1;
        count = 1;
        for (k = 1; k < players; k++) {
            if (winner < playerScore.get(k).totalPoints()) {
                winner = playerScore.get(k).totalPoints();
                intArray[0] = k+1;
                count = 1;
            } else if (playerScore.get(k).totalPoints() == winner) {
                intArray[count] = (k + 1);
                count = count + 1;
            }
        }
        return intArray;
    }

    //still have to make a case where we have two winners.
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(playerScore.get(0).totalPoints());
        for (int j = 1; j < players; j++) {
            sb.append(" VS " + playerScore.get(j).totalPoints());
        }
        sb.append(", Winner Player(s) :");
        getWinner();
        sb.append(intArray[0]);
        for (int index = 1; index < count; index++) {
            sb.append("," + intArray[index]);
        }
        sb.append("(" + timeDate + ")");
        sb.append(" ");
        return sb.toString();
    }
}
