package ca.cmpt276.as2.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GameManager implements Iterable <Game>{

    private List<Game> games = new ArrayList<>();

    public void add(Game game){
        games.add(game);
    }
    public void remove(int i){
        games.remove(i);
    }

    @Override
    public Iterator<Game> iterator() {
        return games.iterator();

    }
}

