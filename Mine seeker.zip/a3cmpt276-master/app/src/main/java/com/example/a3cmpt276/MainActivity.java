package com.example.a3cmpt276;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        StartActivity();
        OptionsActivity();
        InstructionsActivity();
    }

    private void  StartActivity(){
        Button b1 = findViewById(R.id.playbutton);
        b1.setOnClickListener((v)->{
            Intent i = PlayGame.makeLaunch(MainActivity.this);
            startActivity(i);
        });
    }

    private void  OptionsActivity(){
        Button b2 = findViewById(R.id.optbutton);
        b2.setOnClickListener((v)->{
            Intent i = Options.makeLaunch(MainActivity.this);
            startActivity(i);
        });
    }

    private void  InstructionsActivity(){
        Button b3 = findViewById(R.id.Instbutton);
        b3.setOnClickListener((v)->{
            Intent i = Instructions.makeLaunch(MainActivity.this);
            startActivity(i);
        });
    }

    public static Intent makeLaunch(Context c){
        return new Intent(c, MainActivity.class);
    }


}
