package com.example.a3cmpt276;

import static android.widget.Toast.LENGTH_SHORT;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Options extends AppCompatActivity {
    private PlayGame game;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);


        game = PlayGame.getInstance();

        Button button = findViewById(R.id.saveButton);
        button.setOnClickListener((v)->{
            RadioGroup radioGroup1 = findViewById(R.id.radioGroup1);
            RadioButton radioButton1;
            int id1 = radioGroup1.getCheckedRadioButtonId();
            RadioGroup radioGroup2 = findViewById(R.id.radioGroup1);
            RadioButton radioButton2;
            int id2 = radioGroup2.getCheckedRadioButtonId();
            if(id1 != -1 && id2 !=-1){
                radioButton1 = findViewById(id1);
                String buttonString = radioButton1.getText().toString();
                radioButton2 = findViewById(id2);
                String buttonString2 = radioButton2.getText().toString();

                Toast.makeText(Options.this, "You selected " + buttonString + " layout and "
                + buttonString2 + "Mines", LENGTH_SHORT);
                String[] array = buttonString.split("x");

                game.setRows(Integer.parseInt(array[0]));
                game.setColumns(Integer.parseInt(array[0]));
                game.setMines(Integer.parseInt(buttonString2));
            }
            else {
                Toast.makeText(Options.this, "Select both mines and layout", LENGTH_SHORT).show();
            }
            Intent intent = MainActivity.makeLaunch(Options.this);
            startActivity(intent);

        });

        Button cancel = findViewById(R.id.cancelButton);
        cancel.setOnClickListener((v)->{
            Intent intent = MainActivity.makeLaunch(Options.this);
            startActivity(intent);
        });
    }

    public static Intent makeLaunch(Context c){
        return new Intent(c, Options.class);
    }
}