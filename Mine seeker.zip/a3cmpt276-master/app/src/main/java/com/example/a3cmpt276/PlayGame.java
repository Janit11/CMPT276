package com.example.a3cmpt276;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.Random;

public class PlayGame extends AppCompatActivity {


    private Handler mHandler;
    private static int mines = 5;
    private static int row = 5;
    private static int column = 5;

    Button buttons [][]= new Button[row][column];
    int [][] position = new int [row][column];

    public static void setRows(int row) {
        PlayGame.row = row;
    }

    public static void setColumns(int column) {
        PlayGame.column = column;
    }

    public static void setMines(int mines) {PlayGame.mines = mines;}

    private static PlayGame instance;

    public static PlayGame getInstance() {
        if(instance == null){
            instance = new PlayGame();
        }
        return instance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_game);
        mHandler = new Handler();


        makeTable();
        MakeRowsColumns(row, column, mines);
    }

    public void MakeRowsColumns(int rows1, int columns1, int mines1) {

        SharedPreferences prefs = this.getSharedPreferences("AppPrefs", MODE_PRIVATE);

        SharedPreferences.Editor editor = prefs.edit();

        setRows(rows1);
        setColumns(columns1);
        setMines(mines1);

        editor.putInt("Num of Rows", row);
        editor.putInt("Num of Cols", column);
        editor.putInt("Num of Mine", mines);

        editor.apply();
    }

    private void makeTable(){
        TableLayout tableLayout = findViewById(R.id.tableLayout);
        final int [] minesCount = {0};
        final int [] scansCount = {0};

        for(int i = 0; i< row; i++){
            TableRow tableRow = new TableRow(this);
            tableRow.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT,
                            TableLayout.LayoutParams.MATCH_PARENT, 1.0f));
            tableLayout.addView(tableRow);

            for(int j = 0; j<column; j++){
                final Button button = new Button(this);
                button.setLayoutParams(new TableRow.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT,
                        TableLayout.LayoutParams.MATCH_PARENT, 1.0f));

                final int columns = j;
                final int rows = i;


                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        lockButtonsSizes();
                        button.setClickable(false);
                        mHandler.postDelayed(()->{
                            if(position[rows][columns]==5){

                                mine(rows,columns);
                                minesCount[0]++;
                                counterUpdate(rows,columns);
                            }if(position[rows][columns]!=5){
                                scansCount[0]++;
                                counterUpdate(rows,columns);
                            }
                            setNewCounter(scansCount[0],minesCount[0]);
                        },1000);


                    }
                });

                tableRow.addView(button);
                buttons[i][j] = button;
            }
        }
        for(int k = 0; k<mines; k++){
            Random random = new Random();
            final int rand1 = random.nextInt(row);
            final int rand2 = random.nextInt(column);

            if(position[rand1][rand2]!=5){
                position[rand1][rand2]=5;
            }else
                k--;
        }
    }

    private void lockButtonsSizes(){
        for(int i =0; i<row; i++){
            for(int j =0; j<column; j++){
                Button button = buttons[i][j];

                int width = button.getWidth();
                button.setMinWidth(width);
                button.setMaxWidth(width);

                int height = button.getWidth();
                button.setMinWidth(height);
                button.setMaxWidth(height);
            }
        }
    }



    private void counterUpdate(int rows1, int columns1){
        for(int i = 0; i<row; i++){
            Button button = buttons[i][columns1];

            if(!button.isClickable()){
                int count1 = counter(i,columns1);
                button.setText(String.valueOf(count1));
            }
        }
        for(int j = 0; j<column; j++){
            Button button = buttons[rows1][j];

            if(!button.isClickable()){
                int count2 = counter(rows1,j);
                button.setText(String.valueOf(count2));
            }
        }
    }
    private int counter(int rows1, int columns1){
        int count =0;
        for(int i = 0; i<row; i++){
            if(position[i][columns1]==5){
                count++;
            }
        }
        for(int j = 0; j<column; j++){
            if(position[rows1][j]==5){
                count++;
            }
        }
        return count;
    }
    private void setNewCounter(int scansCounter, int minesCounter){
        TextView mine = findViewById(R.id.mineCount);
        TextView scan = findViewById(R.id.scanCount);
        scan.setText(Integer.toString(scansCounter));
        mine.setText(Integer.toString(minesCounter));
        mine.setText(Integer.toString(minesCounter) + " out of " + mines);

        if(mines == minesCounter){
            endThisGame();
        }
    }

    private void mine(int rows1, int columns1){
        Button button = buttons[rows1][columns1];
        int height = button.getHeight();
        int width = button.getWidth();

        Bitmap originalBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.mine1);

        Bitmap scaledBitmap = Bitmap.createScaledBitmap(originalBitmap, width, height, true);

        Resources resource = getResources();
        button.setBackground(new BitmapDrawable(resource,scaledBitmap));
        position[rows1][columns1]=0;
        counterUpdate(rows1,columns1);
    }

    private void endThisGame(){
        AlertDialog.Builder builder = new AlertDialog.Builder(PlayGame.this);
        View v = LayoutInflater.from(PlayGame.this).inflate(R.layout.victory, null);
        builder.setTitle("Woohoo Victory. All mines found!!");
        builder.setMessage("Congratulations! You've completed this game.")
                .setPositiveButton("Ok", (dialog, which)->{
                    Intent intent = MainActivity.makeLaunch(PlayGame.this);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                });

        builder.setView(v);
        builder.create();
        builder.show();

    }
    public static Intent makeLaunch(Context c){
        return new Intent(c, PlayGame.class);
    }
}
